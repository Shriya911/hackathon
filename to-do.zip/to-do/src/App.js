import React from 'react';
import DeployAndInteract from './DeployAndInteract';

const App = () => {
  return (
    <div>
      <h1>Smart Contract Interaction</h1>
      <DeployAndInteract />
    </div>
  );
};

export default App;
