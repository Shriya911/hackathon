import React, { useState } from 'react';
import Web3 from 'web3';

// Initialize Web3
const web3 = new Web3('http://localhost:8545'); // Connect to your Ethereum node

// Replace with your contract's ABI and deployed contract address
const contractABI = [
  {
    "inputs": [
      { "internalType": "string", "name": "_content", "type": "string" }
    ],
    "name": "createTask",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  // Add other ABI entries as needed
];
const contractAddress = '0x1234567890abcdef1234567890abcdef12345678'; // Replace with your contract address

const DeployAndInteract = () => {
  const [taskContent, setTaskContent] = useState('');
  const [message, setMessage] = useState('');

  const createTask = async () => {
    try {
      const accounts = await web3.eth.getAccounts();
      const contract = new web3.eth.Contract(contractABI, contractAddress);

      await contract.methods.createTask(taskContent).send({ from: accounts[0] });
      setMessage('Task created successfully!');
    } catch (error) {
      console.error('Error creating task:', error);
      setMessage('Failed to create task. Check console for errors.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-100">
      <h2 className="text-2xl font-bold mb-4">Create a Task</h2>
      <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-lg">
        <input
          type="text"
          placeholder="Enter task content"
          value={taskContent}
          onChange={(e) => setTaskContent(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded-md mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={createTask}
          className="w-full py-2 px-4 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Create Task
        </button>
        {message && <p className="mt-4 text-center text-red-500">{message}</p>}
      </div>
    </div>
  );
};

export default DeployAndInteract;
